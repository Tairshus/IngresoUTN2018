#include <stdio.h>
#include <stdlib.h>
//int %d decimal %i entero %b binario etc..., float %f, char %c
// getchar() getch() getche()sss
int main()
{
    int numero;
    char letra;

    printf("Ingrese una letra: ");
    scanf("%c", &letra);
    printf("Usted ingreso la letra: %c",letra);

    printf("\nIngrese un numero: ");
    scanf("%d", &numero);
    printf("Usted el numero: %d", numero);

    return 0;
}
