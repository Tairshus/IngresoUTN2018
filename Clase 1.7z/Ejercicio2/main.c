#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero = 5;
    int numero2 = 10;

    printf("La variable numero vale : %d y la variable numero2 tiene un valor de : %d", numero, numero2);
    return 0;
}
