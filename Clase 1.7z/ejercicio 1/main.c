#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hola\nMundo!");
    return 0;
}
